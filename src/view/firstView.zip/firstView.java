package view;


import java.io.FileInputStream;

import com.sun.prism.paint.Color;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class firstView extends Application implements EventHandler<ActionEvent>{
	Image icon =new Image("/images/logo.jpg");
	 Image cover=new Image("/images/covo.jpg");
	 Image BILL = new Image("/images/BILL.png");  
	    Image BILLF = new Image("/images/BILL F.png");
	    Image DAVID = new Image("/images/DAVID.png");
	    Image DAVIDF = new Image("/images/DAVID F.png");
	    Image ELLIE = new Image("/images/ELLIE WILLIAMS.png");
	    Image ELLIEF = new Image("/images/ELLIE WILLIAMS F.png");
	    Image HENRY = new Image("/images/HENRY BURELL.png");
	    Image HENRYF = new Image("/images/HENRY BURELL F.png");  
	    Image JOEL = new Image("/images/JOEL MILLER .png");
	    Image JOELF = new Image("/images/JOEL MILLER F.png");
	    Image RILEY = new Image("/images/RILEY ABEL.png");
	    Image RILEYF = new Image("/images/RILEY ABEL F.png");
	    Image TESS = new Image("/images/TESS.png");
	    Image TESSF = new Image("/images/TESS F.png");
	    Image TOMMY = new Image("/images/TOMMY MILLER.png");
	    Image TOMMYF = new Image("/images/TOMMY MILLER F.png");
	 Stage window; Scene scene1 , scene2;
	 Button b=new Button("PLAY");
	DropShadow shadow = new DropShadow();	
	@Override
	public void start(Stage stage) throws Exception {
		window=stage;
		StackPane sp=new StackPane();
		 
		     ImageView ivC= new ImageView(cover);
		     ivC.setFitHeight(1000);
		     ivC.setFitWidth(1920);
		 Scene scene1 =new Scene(sp,1500,1000);
		 sp.getChildren().addAll(ivC);
		 stage.setTitle("Last of Us - Legacy");
		 stage.getIcons().add(icon);
		//	scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		// ImageView iv=new ImageView(img);
		
		
		
		//b.setMinSize(200,100);
		b.setPrefSize(200,50);
		//b.setWrapText(false);
		b.setStyle("-fx-background-color: PeachPuff");
		b.setStyle("-fx-base: mistyrose;");
		b.setFont(new Font(40));
		//StackPane.setAlignment(b,Pos.BOTTOM_RIGHT);
		b.setAlignment(Pos.CENTER);
		b.setLayoutX(1000);
		b.setLayoutY(950);
		b.setMaxSize(200,50);
		
		
		  b.addEventHandler(MouseEvent.MOUSE_ENTERED,
			        new EventHandler<MouseEvent>() {
			          @Override
			          public void handle(MouseEvent e) {
			        	  b.setStyle("-fx-background-color: MediumTurquoise");
			            b.setEffect(shadow);
			          }
			        });
		/*  b.addEventHandler(MouseEvent.MOUSE_CLICKED,
			        new EventHandler<MouseEvent>() {
			          @Override
			          public void handle(MouseEvent e) {
			        	  //b.setStyle("-fx-background-color: MediumTurquoise");
			            //b.setEffect(shadow);
			          System.out.print(2);
			          }
			        });*/
			    b.addEventHandler(MouseEvent.MOUSE_EXITED,
			        new EventHandler<MouseEvent>() {
			          @Override
			          public void handle(MouseEvent e) {
			        	  b.setStyle("-fx-background-color: PeachPuff");
			            b.setEffect(null);
			          }
			        });

		sp.getChildren().add(b);
		stage.setScene(scene1);
		stage.show();
		/////////////////SCENE 2
		/////////////////////////////////////////////////////
		//////////////////////////////////////////////////////

		 GridPane root = new GridPane();
		 
		 // TODO Auto-generated method stub  
	    
	   
	     
	  //  ((HBox) root).setSpacing(40);
	  // Button b=new Button();
	   
	  // b.setPrefSize(50,50);
	  // b.setMaxSize(30,30);
	   ImageView iv1=new ImageView(BILL);
	   root.add(iv1,0,0,1,1);
	   ImageView iv2=new ImageView(DAVID);
	   root.add(iv2,0,1,1,1);
		 ImageView iv3=new ImageView(ELLIE);
		 root.add(iv3,1,1,1,1);
		 ImageView iv4=new ImageView(HENRY);
		 root.add(iv4,1,0,1,1);
		 ImageView iv5=new ImageView(JOEL);
		 root.add(iv5,2,1,1,1);
		 ImageView iv6=new ImageView(RILEY);
		 root.add(iv6,2,0,1,1);
		 ImageView iv7=new ImageView(TESS);
		 root.add(iv7,3,0,1,1);
		 ImageView iv8=new ImageView(TOMMY);
		 root.add(iv8,3,1,1,1);
		
	
	   //root.setMaxSize(100,100);
	 
	  iv1.addEventHandler(MouseEvent.MOUSE_CLICKED,
		        new EventHandler<MouseEvent>() {
		          @Override
		          public void handle(MouseEvent e) {
		        	  //b.setStyle("-fx-background-color: MediumTurquoise");
		            //b.setEffect(shadow);
		          System.out.print(2);
		          }
		        });
	  iv1.addEventHandler(MouseEvent.MOUSE_ENTERED,
		        new EventHandler<MouseEvent>() {
		          @Override
		          public void handle(MouseEvent e) {
		        	  //b.setStyle("-fx-background-color: MediumTurquoise");
		            //b.setEffect(shadow);
		        	  iv1.setImage(new Image("/images/BILL F.png"));
		          //System.out.print(2);
		          }
		        });
  
iv1.addEventHandler(MouseEvent.MOUSE_EXITED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  //b.setStyle("-fx-background-color: MediumTurquoise");
          //b.setEffect(shadow);
      	  iv1.setImage(new Image("/images/BILL.png"));
        //System.out.print(2);
        }
      });


iv2.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  //b.setStyle("-fx-background-color: MediumTurquoise");
          //b.setEffect(shadow);
        System.out.print(2);
        }
      });
iv2.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  //b.setStyle("-fx-background-color: MediumTurquoise");
          //b.setEffect(shadow);
      	  iv2.setImage(new Image("/images/DAVID F.png"));
        //System.out.print(2);
        }
      });

iv2.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	  //b.setStyle("-fx-background-color: MediumTurquoise");
  //b.setEffect(shadow);
	  iv2.setImage(new Image("/images/DAVID.png"));
//System.out.print(2);
}
});



iv3.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  
        }
      });
iv3.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  
      	  iv3.setImage(new Image("/images/ELLIE WILLIAMS F.png"));
        
        }
      });

iv3.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	 
	  iv3.setImage(new Image("/images/ELLIE WILLIAMS.png"));

}
});


iv4.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	 
        System.out.print(2);
        }
      });
iv4.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	 
      	  iv4.setImage(new Image("/images/HENRY BURELL F.png"));
        
        }
      });

iv4.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	 
	  iv4.setImage(new Image("/images/HENRY BURELL.png"));

}
});



iv5.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  
        
        }
      });
iv5.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	 
      	  iv5.setImage(new Image("/images/JOEL MILLER F.png"));
        
        }
      });

iv5.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	 
	  iv5.setImage(new Image("/images/JOEL MILLER .png"));

}
});



iv6.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  
        }
      });
iv6.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	 
      	  iv6.setImage(new Image("/images/RILEY ABEL F.png"));
       
        }
      });

iv6.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	 
	  iv6.setImage(new Image("/images/RILEY ABEL.png"));

}
});



iv7.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  
        System.out.print(2);
        }
      });
iv7.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	  
      	  iv7.setImage(new Image("/images/TESS F.png"));
       
        }
      });

iv7.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	 
	  iv7.setImage(new Image("/images/TESS.png"));

}
});



iv8.addEventHandler(MouseEvent.MOUSE_CLICKED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	 
        
        }
      });
iv8.addEventHandler(MouseEvent.MOUSE_ENTERED,
      new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent e) {
      	 
      	  iv8.setImage(new Image("/images/TOMMY MILLER F.png"));
       
        }
      });

iv8.addEventHandler(MouseEvent.MOUSE_EXITED,
new EventHandler<MouseEvent>() {
@Override
public void handle(MouseEvent e) {
	
	  iv8.setImage(new Image("/images/TOMMY MILLER.png"));

}
});
Scene scene2 = new Scene(root,1500,1000); 
b.setOnAction(e -> window.setScene(scene2));


	   
	 
		
		
		
		
		
	}

	@Override
	public void handle(ActionEvent event) {
		//if(event.getSource()==b)
			//window.setScene(scene2);
	
	
		
		
	}
	public static void main(String[]args){
		launch(args);
		
	}
	

}

